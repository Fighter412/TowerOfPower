# Video-PyGame
The source code for my YouTube tutorial on how to play videos using Python and PyGame.

Code for pyvidplayer.py made by ree1261 on GitHub.
